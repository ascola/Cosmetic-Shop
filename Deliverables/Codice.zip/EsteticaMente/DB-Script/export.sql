CREATE DATABASE  IF NOT EXISTS `esteticamente`;
USE `esteticamente`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: cosmeticShop
-- ------------------------------------------------------
-- Server version	5.7.16-log

--
-- Table structure for table `carrello`
--

DROP TABLE IF EXISTS `carrello`;
CREATE TABLE `carrello` (
  `utenteCarrello` varchar(30) NOT NULL,
  `idCarrello` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idCarrello`),
  KEY `chiaveEsterna6` (`utenteCarrello`),
  CONSTRAINT `chiaveEsterna6` FOREIGN KEY (`utenteCarrello`) REFERENCES `utente` (`username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `carrello`
--

LOCK TABLES `carrello` WRITE;
INSERT INTO `carrello` VALUES ('antonellaDeVITa',2),('elenatroiano',3),('lauraDeVita',4),('luonaScola',1),('pamelaSCola',5);
UNLOCK TABLES;

--
-- Table structure for table `ordine`
--

DROP TABLE IF EXISTS `ordine`;
CREATE TABLE `ordine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `utenteOrdine` varchar(30) NOT NULL,
  `prezzoTotale` double(15,2) DEFAULT NULL,
  `stato` enum('Da Spedire','Spedito','Arrivato') NOT NULL,
  `iban` varchar(35) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `chiaveEsterna1` (`utenteOrdine`),
  CONSTRAINT `chiaveEsterna1` FOREIGN KEY (`utenteOrdine`) REFERENCES `utente` (`username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;


--
-- Dumping data for table `ordine`
--

LOCK TABLES `ordine` WRITE;
INSERT INTO `ordine` VALUES (1,'antonellaDeVITa',34.50,'Da Spedire','IT02 L123 4512 3451 2345 6789 012'),(2,'elenatroiano',50.10,'Spedito','IT02 L123 4512 3451 2345 6789 012'),(3,'lauraDeVita',20.44,'Arrivato','IT02 L123 4512 3451 2345 6789 012'),(4,'pamelaSCola',5.00,'Da Spedire','IT02 L123 4512 3451 2345 6789 012'),(5,'luonaScola',26.70,'Spedito','IT02 L123 4512 3451 2345 6789 012'),(6,'luonaScola',77.70,'Da Spedire','IT02 L123 4512 3451 2345 6789 012');
UNLOCK TABLES;

--
-- Table structure for table `prodotticarrello`
--

DROP TABLE IF EXISTS `prodotticarrello`;
CREATE TABLE `prodotticarrello` (
  `numeroSequenza` int(11) NOT NULL AUTO_INCREMENT,
  `numeroCarrello` int(11) NOT NULL,
  `idProdottoCarrello` int(11) NOT NULL,
  `quantitaProdotto` int(11) DEFAULT NULL,
  PRIMARY KEY (`numeroSequenza`),
  KEY `chiaveEsterna7` (`numeroCarrello`),
  KEY `chiaveEsterna8` (`idProdottoCarrello`),
  CONSTRAINT `chiaveEsterna7` FOREIGN KEY (`numeroCarrello`) REFERENCES `carrello` (`idCarrello`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `chiaveEsterna8` FOREIGN KEY (`idProdottoCarrello`) REFERENCES `prodotto` (`idProdotto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `prodotticarrello`
--

LOCK TABLES `prodotticarrello` WRITE;
INSERT INTO `prodotticarrello` VALUES (1,1,1,4),(2,1,2,7),(3,2,3,2),(4,2,4,6),(5,3,5,2),(6,3,6,3),(7,4,7,11),(8,4,8,16),(9,5,9,12),(10,5,10,15);
UNLOCK TABLES;

--
-- Table structure for table `prodottiordine`
--

DROP TABLE IF EXISTS `prodottiordine`;
CREATE TABLE `prodottiordine` (
  `numeroLista` int(11) NOT NULL AUTO_INCREMENT,
  `idOrdine` int(11) NOT NULL,
  `idProdottoLista` int(11) NOT NULL,
  `numeroProdotto` int(10) DEFAULT NULL,
  PRIMARY KEY (`numeroLista`),
  KEY `chiaveEsterna3` (`idOrdine`),
  KEY `chiaveEsterna4` (`idProdottoLista`),
  CONSTRAINT `chiaveEsterna3` FOREIGN KEY (`idOrdine`) REFERENCES `ordine` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `chiaveEsterna4` FOREIGN KEY (`idProdottoLista`) REFERENCES `prodotto` (`idProdotto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `prodottiordine`
--

LOCK TABLES `prodottiordine` WRITE;
INSERT INTO `prodottiordine` VALUES (1,1,10,4),(2,1,1,30),(3,2,13,51),(4,2,12,66),(5,3,9,24),(6,3,5,12),(7,4,8,8),(8,4,2,71),(9,5,4,20),(10,5,4,20),(11,6,8,18),(12,6,7,18);
UNLOCK TABLES;

--
-- Table structure for table `prodotto`
--

DROP TABLE IF EXISTS `prodotto`;
CREATE TABLE `prodotto` (
  `idProdotto` int(11) NOT NULL AUTO_INCREMENT,
  `urlImmagine` varchar(250) DEFAULT NULL,
  `nome` varchar(30) NOT NULL,
  `quantita` int(15) DEFAULT NULL,
  `descrizione` varchar(255) DEFAULT NULL,
  `prezzo` double(15,2) DEFAULT NULL,
  PRIMARY KEY (`idProdotto`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `prodotto`
--

LOCK TABLES `prodotto` WRITE;
INSERT INTO `prodotto` VALUES (1,'./Immagini/lipglosslancome.jpg','LIPGLOSS LANCOME',40,'Vesti le tue labbra di un gloss a lunga durata.',12.30),(2,'./Immagini/blush.jpg','BLUSH NEVE COSMETIC',40,'Incarnato luminoso e raggiante grazie all\'esclusivo make up firmato NEVE COSMETIC',4.10),(3,'./Immagini/smalto.jpg','SMALTO CHANEL',40,'Smalti brillanti e a lunga tenuta: tutta la linea in esclusiva da CHANEL.',11.00),(4,'./Immagini/fondotinta.jpg','FONDOTINTA MAC',40,'UN BALSAMO COLORATO ULTRA FLUIDO CON INGREDIENTI NUTRIENTI E MICROSFERE OPALESCENTI CHE APPORTA UNA LUMINOSITÀ NATURALE ALLA PELLE.',23.50),(5,'./Immagini/matita.jpg','MATITA OCCHI MAC',40,'MATITE occhi divise per finish. MAC Urban decay Zoeva. ',6.00),(6,'./Immagini/ombretti.jpg','OMBRETTI MAC',40,'Ideale per valorizzare gli occhi, donando profondità allo sguardo.',9.90),(7,'./Immagini/eyeliner.jpg','EYELINER AVON',40,'Ideale per valorizzare gli occhi, donando profondità allo sguardo.',10.50),(8,'./Immagini/mascara.jpg','MASCARA LAM',40,'Ideale per valorizzare gli occhi, donando profondità allo sguardo.',9.30),(9,'./Immagini/pennello.jpg','PENNELLO VISO PUNTOBIO',40,'Ideale per BLUSH e FARD',7.55),(10,'./Immagini/ciprima.jpg','CIPRIA CHANEL',40,'Ideale per donare luce e luminisità al viso',7.20),(11,'./Immagini/illuminante.jpg','ILLUMINANTE ESSENCE',40,'Ideale per donare luce e luminisità al viso',8.90),(12,'./Immagini/cipriahd.jpg','CIPRIA HD PROFESSIONAL',40,'Ideale per donare luce e luminisità al viso per nascondere le imperfezioni',5.50),(13,'./Immagini/tintalabbra.jpg','TINTA LABBRA MALTED',40,'Ideale per ingrandire le labbra',4.40);
UNLOCK TABLES;

--
-- Table structure for table `utente`
--

DROP TABLE IF EXISTS `utente`;
CREATE TABLE `utente` (
  `ruolo` enum('utente','amministratore') NOT NULL,
  `nome` char(30) DEFAULT NULL,
  `cognome` char(30) DEFAULT NULL,
  `eMail` varchar(30) NOT NULL,
  `codiceFiscale` varchar(16) NOT NULL,
  `dataNascita` varchar(16) NOT NULL,
  `cittaNascita` varchar(40) DEFAULT NULL,
  `cittaResidenza` varchar(40) DEFAULT NULL,
  `via` varchar(30) DEFAULT NULL,
  `numeroCivico` int(4) DEFAULT NULL,
  `cap` int(11) DEFAULT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Dumping data for table `utente`
--

LOCK TABLES `utente` WRITE;
INSERT INTO `utente` VALUES ('utente','Antonella','De Vita','rocad@libero.it','ANTONELLA74DJJDJ','1974-07-11','trieste','udine','via roma',81,82034,'antonellaDeVITa','pinko'),('amministratore','Aurora','Scola','as@outlook.it','AURORACOLA96FKP','1996-08-24','salerno','roccapiemonte','via pace',84,82082,'auroraScola','pippo'),('utente','Elena','Troiano','et@libero.it','ELENATRO96DJDJJD','1996-08-21','roma','salerno','via libertas',24,82034,'elenatroiano','elet'),('utente','Laura','De Vita','ld@libero.it','LAURADEVITA96DDK','1977-09-23','roma','salerno','via libertas',24,82034,'lauraDeVita','pinko'),('utente','Luona',' Scola','ls@libero.it','LUSCOLA98EUEUEUE','1998-10-06','roma','salerno','via libertas',24,82034,'luonaScola','pinko'),('utente','Pamela','Scola','ps@libero.it','PAMELASCOLA2005G','2005-09-21','napoli','casandrino','via vittoria',43,82022,'pamelaSCola','pinko');
UNLOCK TABLES;


