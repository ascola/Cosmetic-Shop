use esteticamente;

show tables;

describe  utente;
describe  prodotto ;
describe  ordine;
describe  prodottiordine;
describe  carrello;
describe  prodotticarrello;

select * from   utente;
select * from   prodotto ;
select * from   ordine;
select * from   prodottiordine;
select * from   carrello;
select * from   prodotticarrello;

show processlist;