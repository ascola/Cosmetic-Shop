package beanTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import bean.Prodotto;

class ProdottoTest {
	
	Prodotto prodotto;

	@BeforeEach
	void setUp() throws Exception {
		prodotto = new Prodotto(10, "test", "img/testImmagine.jpg", "test", 10, 10.0);
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	final void testProdotto() {
		prodotto = new Prodotto(10, "test", "img/testImmagine.jpg", "test", 10, 10.0);
		assertNotNull(prodotto);
		
		Prodotto prodotto2= new Prodotto("test.img", "test", 10, "test", 4.10);
		assertNotNull(prodotto2);
		
		Prodotto prodotto3 = new Prodotto("test", 10, "test", 1.99);
		assertNotNull(prodotto3);
	}


	@Test
	final void testGetQuantita() {
		assertEquals(10,prodotto.getQuantita());
	}

	@Test
	final void testGetPrezzo() {
		assertEquals(10,prodotto.getPrezzo());
	}

	@Test
	final void testGetNome() {
		assertEquals("test",prodotto.getNome());
	}

	@Test
	final void testGetIdProdotto() {
		assertEquals(10,prodotto.getIdProdotto());
	}

	@Test
	final void testGetDescrizione() {
		assertEquals("test", prodotto.getDescrizione());
	}

	@Test
	final void testGetUrlImmagine() {
		assertEquals("img/testImmagine.jpg",prodotto.getUrlImmagine());
	}

	@Test
	final void testSetQuantita() {
		assertEquals(10, prodotto.getQuantita());
	}

	@Test
	final void testSetPrezzo() {
		prodotto.setPrezzo(20.0);
		assertEquals(20.0, prodotto.getPrezzo());
	}

	@Test
	final void testSetNome() {
		prodotto.setNome("utente2");
		assertEquals("utente2", prodotto.getNome());
	}

	@Test
	final void testSetIdProdotto() {
		prodotto.setIdProdotto(20);
		assertEquals(20, prodotto.getIdProdotto());
	}

	@Test
	final void testSetDescrizione() {
		prodotto.setDescrizione("descrizione");
		assertEquals("descrizione", prodotto.getDescrizione());
	}

	@Test
	final void testSetUrlImmagine() {
		prodotto.setUrlImmagine("url2/img.png");
		assertEquals("url2/img.png", prodotto.getUrlImmagine());
	}

}
