package beanTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import bean.Utente;

class UtenteTest {
	
	Utente utente;
	
	@BeforeEach
	void setUp() throws Exception {
		utente = new Utente("ruolo", "nome", "cognome", "email@email.it", "codicefiscale", "11/11/1992", "nascita", "residenza",
				"via", 10, 10, "username", "password");
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	final void testUtente() {
		utente = new Utente("ruolo", "nome", "cognome", "email@email.it", "codicefiscale", "11/11/1992", "nascita", "residenza",
				"via", 10, 10, "username", "password");
		assertNotNull(utente);
	}


	@Test
	final void testGetCap() {
		assertEquals(10,utente.getCap());
	}

	@Test
	final void testGetCittaNascita() {
		assertEquals("nascita",utente.getCittaNascita());
	}

	@Test
	final void testGetCittaResidenza() {
		assertEquals("residenza", utente.getCittaResidenza());
	}

	@Test
	final void testGetCodiceFiscale() {
		assertEquals("codicefiscale", utente.getCodiceFiscale());
	}

	@Test
	final void testGetDataNascita() {
		assertEquals("11/11/1992", utente.getDataNascita());
	}

	@Test
	final void testGetNome() {
		assertEquals("nome", utente.getNome());
	}

	@Test
	final void testGetCognome() {
		assertEquals("cognome", utente.getCognome());
	}

	@Test
	final void testGeteMail() {
		assertEquals("email@email.it",utente.geteMail());
	}

	@Test
	final void testGetVia() {
		assertEquals("via", utente.getVia());
	}

	@Test
	final void testGetNumeroCivico() {
		assertEquals(10, utente.getNumeroCivico());
	}

	@Test
	final void testGetPassword() {
		assertEquals("password", utente.getPassword());
	}

	@Test
	final void testGetUsername() {
		assertEquals("username", utente.getUsername());
	}

	@Test
	final void testGetRuolo() {
		assertEquals("ruolo", utente.getRuolo());
	}

	@Test
	final void testSetCap() {
		utente.setCap(50);
		assertEquals(50, utente.getCap());
	}

	@Test
	final void testSetCittaNascita() {
		utente.setCittaNascita("nascita1");
		assertEquals("nascita1", utente.getCittaNascita());
	}

	@Test
	final void testSetCittaResidenza() {
		utente.setCittaResidenza("residenza1");
		assertEquals("residenza1", utente.getCittaResidenza());
	}

	@Test
	final void testSetCodiceFiscale() {
		utente.setCodiceFiscale("codicefiscale2");
		assertEquals("codicefiscale2", utente.getCodiceFiscale());
	}

	@Test
	final void testSetCognome() {
		utente.setCognome("cognome2");
		assertEquals("cognome2", utente.getCognome());
	}

	@Test
	final void testSetDataNascita() {
		utente.setDataNascita("09/09/2000");
		assertEquals("09/09/2000", utente.getDataNascita());
	}

	@Test
	final void testSetRuolo() {
		utente.setRuolo("ruolo2");
		assertEquals("ruolo2", utente.getRuolo());
	}

	@Test
	final void testSetNome() {
		utente.setNome("nomeTest");
		assertEquals("nomeTest", utente.getNome());
	}

	@Test
	final void testSeteMail() {
		utente.seteMail("emailTest@test.com");
		assertEquals("emailTest@test.com", utente.geteMail());
	}

	@Test
	final void testSetPassword() {
		utente.setPassword("passwordtest");
		assertEquals("passwordtest", utente.getPassword());
	}

	@Test
	final void testSetNumeroCivico() {
		utente.setNumeroCivico(1000);
		assertEquals(1000, utente.getNumeroCivico());
	}

	@Test
	final void testSetUsername() {
		utente.setUsername("usernametest");
		assertEquals("usernametest",utente.getUsername());
	}

	@Test
	final void testSetVia() {
		utente.setVia("viatest");
		assertEquals("viatest", utente.getVia());
	}

}
