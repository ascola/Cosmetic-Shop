package modelTest;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.*;

//import com.mysql.jdbc.Connection;
//import com.mysql.jdbc.PreparedStatement;

import bean.Utente;
import model.UtenteModel;

class UtenteModelTest {
	
	UtenteModel utenteModel;
	Connection conn= null;
	

	

	@BeforeEach
	void setUp() throws Exception {
		
		//Aggiungo un nuovo utente di test prima di ogni metodo di test con username='test' e password='test'
		utenteModel = new UtenteModel();
		conn = (Connection) utenteModel.getConnection();
		
		String insertSQL = "insert into utente (ruolo,nome,cognome,eMail,codiceFiscale,dataNascita,"
				+ "cittaNascita,cittaResidenza,via,numeroCivico,cap,username,password)"
				+ "values('utente','test','test','test','test','test','test','test','test',1,10,'test', MD5('test'))";
		PreparedStatement preparedStatement2 = (PreparedStatement) conn.prepareStatement(insertSQL);
		preparedStatement2.executeUpdate();
	}
	

	@AfterEach
	void tearDown() throws Exception {
		
		//elimino l'utente di test per non sporcare il db
		String deleteSQL = "delete from utente where username='test'";
		PreparedStatement preparedStatement4 = (PreparedStatement) conn.prepareStatement(deleteSQL);
		preparedStatement4.executeUpdate();
	}
	
	
	@Test
	final void testInsertUser() throws SQLException {
		//cancello l'utente di prova inserito nel setup
		String deleteSQL = "delete from utente where username='test'";
		PreparedStatement preparedStatement4 = (PreparedStatement) conn.prepareStatement(deleteSQL);
		preparedStatement4.executeUpdate();
		
		//creo il nuovo utente da passare come utente al metodo
		Utente user = new Utente("utente", "test", "test", "test@test.com", "codiceFiscale",
				"23/03/1990", "test", "test", "test", 100, 1000, "test", "test");
		
		utenteModel.InsertUser(user);
		
		
		//prendo il nome dell'utente appena inserito e controllo se sia 'test'
		String SQL ="select * from utente where nome='test'";
			
			PreparedStatement preparedStatement1 = (PreparedStatement) conn.prepareStatement(SQL);
			ResultSet rs = preparedStatement1.executeQuery();
			String nome="";
			if(rs.next()) {
				nome = rs.getString(2);
				
			}
			
			assertEquals("test", nome);
	}
	
	

	@Test
	final void testGetConnection() throws SQLException {
		assertNotNull(utenteModel.getConnection());
	}
	
	
	
	
	@Test
	final void testVerifyAccess() throws SQLException {
		
		assertEquals("utente",utenteModel.verifyAccess("test", "test"));
		
	}

	@Test
	final void testReturnInfo() throws SQLException {
		Utente u = utenteModel.returnInfo("test");
		String nome = u.getNome();
		assertEquals("test",nome);
	}

	@Test
	final void testControllUser() throws SQLException {
		
		
		//provo a passare una username non esistente
		assertEquals(false,utenteModel.controllUser("testNegativo"));
		
		utenteModel.controllUser("test");
		
		
		//controllo se l'utente di test trovato dal metodo ed esista nel db
		String SQL ="select * from utente where nome='test'";
		
		PreparedStatement preparedStatement1 = (PreparedStatement) conn.prepareStatement(SQL);
		ResultSet rs = preparedStatement1.executeQuery();
		String nome="";
		if(rs.next()) {
			nome = rs.getString(2);
			
		}
		
		assertEquals("test", nome);	
		
	}
	
	
	@Test
	final void testModificaAccount() throws SQLException {
		
		
		//creo l'utente modificato da passare al metodo per la modifica
		Utente user1 = new Utente("utente", "testModifica", "test", "test", "test",
				"test", "test", "test", "test", 1, 10, "test1", "test1");
		
		utenteModel.modificaAccount(user1, "test");
		
		
		
		//controllo che effettivamente � stato modificato nel db l'account dell'utente di test
		String SQL ="select * from utente where username='test1'";
		
		PreparedStatement preparedStatement1 = (PreparedStatement) conn.prepareStatement(SQL);
		ResultSet rs = preparedStatement1.executeQuery();
		String nome="";
		if(rs.next()) {
			nome = rs.getString(2);
			
		}
		
		assertEquals("testModifica", nome);
		
		
		String deleteSQL = "delete from utente where username='test1'";
		PreparedStatement preparedStatement4 = (PreparedStatement) conn.prepareStatement(deleteSQL);
		preparedStatement4.executeUpdate();
		
	}


	@Test
	final void testModificaUtente() throws SQLException {
		Utente user2 = new Utente("utente", "testModifica", "test", "testModifica@test.com", "codiceFiscale",
				"23/03/1990", "test", "test", "test", 100, 1000, "test", "test");
		
		utenteModel.modificaUtente(user2, "test");
		
		
		String SQL ="select * from utente where username='test'";
		
		PreparedStatement preparedStatement1 = (PreparedStatement) conn.prepareStatement(SQL);
		ResultSet rs = preparedStatement1.executeQuery();
		String email="";
		if(rs.next()) {
			email = rs.getString(4);
			
		}
		
		assertEquals("testModifica@test.com", email);
		
		
	}

	

	
	@Test
	final void testEliminaUtente() throws SQLException {
		
		//provo a eliminare un utente che non esiste
		assertEquals(false,utenteModel.eliminaUtente("utenteNonEsistente"));
		
		
		utenteModel.eliminaUtente("test");
		
		
		//controllo se l'utente � stato effettivamente cancellato
		String SQL ="select * from utente where username='test'";
		
		PreparedStatement preparedStatement1 = (PreparedStatement) conn.prepareStatement(SQL);
		ResultSet rs = preparedStatement1.executeQuery();
		String nome="";
		if(!rs.next()) {
			nome = "utenteCancellatoCorrettamente";
			
		}
		
		assertEquals("utenteCancellatoCorrettamente", nome);
		
	}
	

}
