package servlet;


import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Carrello;
import model.CarrelloModel;

@WebServlet("/visualizzaCarrello")
public class VisualizzaCarrello extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	static CarrelloModel model = new CarrelloModel();
	
    public VisualizzaCarrello() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String jsp = null,ruolo = null;
		Carrello elenco = new Carrello();
		
		try {
			ruolo = (String) request.getSession().getAttribute("ruolo");
			String username = (String) request.getSession().getAttribute("username");
			
			
			if("utente".equals(ruolo))
			{
				elenco = model.returnCarrello(username);
				
				jsp = "/Carrello.jsp";
			}else
			{
				if("amministratore".equals(ruolo)){
					jsp = "/HomeAmministratore.jsp";
				}else{
					jsp = "/Login.jsp";
				}
				
			}
	
			request.getSession().setAttribute("Carrello", elenco);
			
		} catch(SQLException e) {
			jsp = "/DatabaseErrore.jsp";
			e.printStackTrace();
		}
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(jsp);
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}

