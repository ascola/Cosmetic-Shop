package servlet;

import java.io.IOException;

import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.CarrelloModel;



@WebServlet("/EliminaProdottoCarrello")
public class EliminaProdottoCarrello extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	static CarrelloModel model = new CarrelloModel();
	String jsp = null;
	int idProdotto =0,quantita=0,numerocarrello=0;
	

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException  {

		//servono username - quantita e id prodotto
		numerocarrello = (Integer.parseInt(request.getParameter("numerocarrello")));
		idProdotto = (Integer.parseInt(request.getParameter("idProdotto")));
		try {
			if(model.eliminaProdottoCarrello(numerocarrello, idProdotto)){
			jsp = "/visualizzaCarrello";
			}else{
				jsp = "/DatabaseErrore.jsp";
			}
		} catch(SQLException e) {
			jsp = "/DatabaseErrore.jsp";
		}
			
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(jsp);
		dispatcher.forward(request, response);
	}
		
}

