package servlet;

import java.io.IOException;

import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Utente;
import model.CarrelloModel;
import model.OrdiniModel;
import model.UtenteModel;



@WebServlet("/AcquistaCarrello")
public class AcquistaCarrello extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	static OrdiniModel modelOrdine = new OrdiniModel();
	static CarrelloModel modelcarrello = new CarrelloModel();
	static UtenteModel model = new UtenteModel();
	String jsp = null;
	Double prezzo =0.0;
	String iban=null;
	int idCarrello = 0;
	Utente ut = null;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException  {

		//servono username - quantita e id prodotto
		String username = (String) request.getSession().getAttribute("username");
		prezzo = (Double.parseDouble(request.getParameter("prezzo")));
		idCarrello =(Integer.parseInt(request.getParameter("idCarrello")));
		int idOrdine =0;
		try {
			//(int idCarrello,String utente, Double prezzo)
			idOrdine =(int) modelOrdine.creaOrdine(idCarrello,username,prezzo);
			//System.out.println(idOrdine);
			ut =(Utente)model.returnInfo(username);
			 request.getSession().setAttribute("idOrdine", idOrdine);
			request.getSession().setAttribute("utente", ut);
			jsp = "/Pagamento.jsp";
		} catch(SQLException e) {
			jsp = "/DatabaseErrore.jsp";
		}
			
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(jsp);
		dispatcher.forward(request, response);
	}
		
}

