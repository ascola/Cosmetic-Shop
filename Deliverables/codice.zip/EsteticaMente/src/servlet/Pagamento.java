package servlet;

import java.io.IOException;

import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.OrdiniModel;



@WebServlet("/Pagamento")
public class Pagamento extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	static OrdiniModel modelOrdine = new OrdiniModel();
	String jsp = null;
	String iban=null;
	int idOrdine = 0;
	

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException  {

		//servono username - quantita e id prodotto
		//String username = (String) request.getSession().getAttribute("username");
		iban = (String)(request.getParameter("iban"));
		idOrdine =(Integer.parseInt(request.getParameter("idOrdine")));
		
		//System.out.println("servlet = "+idOrdine+" - "+username+" - "+iban);
		try {
			//(int idCarrello,String utente, Double prezzo)
			 modelOrdine.inserisciIban(idOrdine, iban);
			 
			jsp = "/ElencoOrdini";
		} catch(SQLException e) {
			jsp = "/DatabaseErrore.jsp";
		}
			
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(jsp);
		dispatcher.forward(request, response);
	}
		
}

