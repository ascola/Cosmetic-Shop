package bean;

import java.io.Serializable;

public class Prodotto implements Serializable{
	
	private String nome ,descrizione,urlImmagine ;
	private int idProdotto ,quantita ;
	private double prezzo;

	private static final long serialVersionUID = 6832305119094378152L;
	
	//costruttori
	public Prodotto() {
	}
	
	public Prodotto(int idProdotto ,String nome ,String urlImmagine,String descrizione,int quantita,Double prezzo) {
		this.idProdotto= idProdotto;
		this.nome = nome;
		this.urlImmagine = urlImmagine;
		this.descrizione = descrizione;
		this.quantita = quantita;
		this.prezzo = prezzo;
	}
	
	public Prodotto(String urlImmagine, String nome ,int quantita,String descrizione,Double prezzo) {
		this.nome = nome;
		this.urlImmagine = urlImmagine;
		this.descrizione = descrizione;
		this.quantita = quantita;
		this.prezzo = prezzo;
	}
	
	public Prodotto(String nome, int quantita, String descrizione, Double prezzo) {
		this.nome = nome;
		this.descrizione = descrizione;
		this.quantita = quantita;
		this.prezzo = prezzo;
	}
	
	//metodi get
	public int getQuantita() {
		return quantita;
	}
	public	double getPrezzo() {
		return prezzo;
	}
	public String getNome() {
		return nome;
	}
	public int getIdProdotto() {
		return idProdotto;
	}
	public String getDescrizione() {
		return descrizione;
	}
	public String getUrlImmagine() {
		return urlImmagine;
	}
	
	//metodi set
	public void setQuantita(int quantita) {
		this.quantita = quantita;
	}
	public void setPrezzo(double prezzo) {
		this.prezzo = prezzo;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public void setIdProdotto(int string) {
		this.idProdotto = string;
	}
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	public void setUrlImmagine(String urlImmagine) {
		this.urlImmagine = urlImmagine;
	}
	
	//metodo toString Prodotto
	@Override
	public String toString() {
		return "Prodotto [nome=" + nome + ", descrizione=" + descrizione + ", urlImmagine=" + urlImmagine
				+ ", idProdotto=" + idProdotto + ", quantita=" + quantita + ", prezzo=" + prezzo + "]";
	}
	

}
