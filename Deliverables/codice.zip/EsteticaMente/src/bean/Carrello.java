package bean;

import java.io.Serializable;
import java.util.ArrayList;

public class Carrello implements Serializable{
	
	private int idCarrello ;
	private ArrayList<Prodotto> prodotto;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3646440982739654423L;
	//costruttori
	public Carrello() {
	}
	
	public Carrello(String utenteCarrello ,int idCarrello ,ArrayList<Prodotto> prodotto) {
		this.utenteCarrello = utenteCarrello;
		this.idCarrello = idCarrello;
		this.prodotto = prodotto;
	}
	
	//metodi get 
	public String getUtenteCarrello() {
		return utenteCarrello;
	}
	public ArrayList<Prodotto> getProdotto() {
		return prodotto;
	}
	public int getIdCarrello() {
		return idCarrello;
	}
	
	//metodi set
	public void setUtenteCarrello(String utenteCarrello) {
		this.utenteCarrello = utenteCarrello;
	}
	public void setProdotto(ArrayList<Prodotto> prodotto) {
		this.prodotto = prodotto;
	}
	public void setIdCarrello(int idCarrello) {
		this.idCarrello = idCarrello;
	}
	//tostring
	
	
	private String utenteCarrello ;
	@Override
	public String toString() {
		return "Carrello [utenteCarrello=" + utenteCarrello + ", idCarrello=" + idCarrello + ", prodotto=" + prodotto
				+ "]";
	}


	
}
