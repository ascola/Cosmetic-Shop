package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import bean.Prodotto;
import bean.Carrello;
import bean.Ordine;

public class OrdiniModel {
	
	public Connection getConnection() throws SQLException {

	    Connection conn = null;
	    try {
	    	Class.forName("com.mysql.jdbc.Driver").newInstance();
	    	  String url = "jdbc:mysql://localhost/fiorazon1";
	    	  conn = DriverManager.getConnection(url, "root", "aurora96");
	    }catch(Exception e) {
	    	e.printStackTrace();
	    }
	    
	    //System.out.println("Connected to database");
	    return conn;
	}
	// __________________________________________________________________________________________________
	
	//restituisce tutti gli ordini effettuati
	public synchronized ArrayList<Ordine> returnOrdini() throws SQLException {
		Connection conn = null;
		PreparedStatement preparedStatement1 = null,preparedStatement2 = null,preparedStatement3 = null;
		ArrayList<Ordine> lista = new ArrayList<Ordine>();
		
		
		String SQL1 = "select * from Ordine";
		String SQL2 = "select idProdottoLista,numeroProdotto from prodottiOrdine where idOrdine = ?";
		String SQL3 = "select * from prodotto where idProdotto = ?";
		
		try {
			conn = getConnection();
			
			preparedStatement1 = conn.prepareStatement(SQL1);
			ResultSet rs = preparedStatement1.executeQuery();
					
			while(rs.next()) {
				Ordine ord = new Ordine();
				ord.setId(rs.getInt("id"));
				ord.setUtenteOrdine(rs.getString("utenteOrdine"));
				ord.setPrezzoTotale(rs.getInt("prezzoTotale"));
				ord.setStato(rs.getString("stato"));
					
				lista.add(ord);
			}
			
			for(Ordine or : lista){
				preparedStatement2 = conn.prepareStatement(SQL2);
				preparedStatement2.setInt(1, or.getId());
				ResultSet rst = preparedStatement2.executeQuery();
				ArrayList<Prodotto> listaProdotto = new ArrayList<Prodotto>();
				while(rst.next()) {
					Prodotto prd = new Prodotto();
						prd.setIdProdotto(rst.getInt("idProdottoLista"));
						prd.setQuantita(rst.getInt("numeroProdotto"));
						//query per informazioni affine prodotto
						preparedStatement3 = conn.prepareStatement(SQL3);
						preparedStatement3.setInt(1, prd.getIdProdotto());
						ResultSet rsx = preparedStatement3.executeQuery();
						while(rsx.next()) {
							prd.setUrlImmagine(rsx.getString("urlImmagine"));
							prd.setNome(rsx.getString("nome"));
							prd.setDescrizione(rsx.getString("descrizione"));
							prd.setPrezzo(rsx.getInt("prezzo"));
						}
							
				//aggiunge prodotto all array
				listaProdotto.add(prd);
				}
				//aggiunge prodotto all ordine
				or.setProdotto(listaProdotto);
			}
			
		} finally {
			try {
				if (preparedStatement1 != null && preparedStatement2 != null && preparedStatement3 != null) {
					preparedStatement3.close();
					preparedStatement2.close();
					preparedStatement1.close();
				}
			} finally {
				if (conn != null)
					conn.close();
			}
		}
		return lista;
	}
	
	//__________________________________________________________________________________________________________
	
	//restituisce gli ordini di un utente
	public synchronized ArrayList<Ordine> returnOrdiniUtente(String username) throws SQLException {
		Connection conn = null;
		PreparedStatement preparedStatement1 = null,preparedStatement2 = null,preparedStatement3 = null;
		ArrayList<Ordine> lista = new ArrayList<Ordine>();
		
		
		String SQL1 = "select * from Ordine where utenteOrdine = ?";
		String SQL2 = "select idProdottoLista,numeroProdotto from prodottiOrdine where idOrdine = ?";
		String SQL3 = "select * from prodotto where idProdotto = ?";
		
		try {
			conn = getConnection();
			
			preparedStatement1 = conn.prepareStatement(SQL1);
			preparedStatement1.setString(1, username);
			ResultSet rs = preparedStatement1.executeQuery();
					
			while(rs.next()) {
				Ordine ord = new Ordine();
				ord.setId(rs.getInt("id"));
				ord.setUtenteOrdine(rs.getString("utenteOrdine"));
				ord.setPrezzoTotale(rs.getInt("prezzoTotale"));
				ord.setStato(rs.getString("stato"));
					
				lista.add(ord);
			}
			
			for(Ordine or : lista){
				preparedStatement2 = conn.prepareStatement(SQL2);
				preparedStatement2.setInt(1, or.getId());
				ResultSet rst = preparedStatement2.executeQuery();
				ArrayList<Prodotto> listaProdotto = new ArrayList<Prodotto>();
				while(rst.next()) {
					Prodotto prd = new Prodotto();
						prd.setIdProdotto(rst.getInt("idProdottoLista"));
						prd.setQuantita(rst.getInt("numeroProdotto"));
						//query per informazioni affine prodotto
						preparedStatement3 = conn.prepareStatement(SQL3);
						preparedStatement3.setInt(1, prd.getIdProdotto());
						ResultSet rsx = preparedStatement3.executeQuery();
						while(rsx.next()) {
							prd.setUrlImmagine(rsx.getString("urlImmagine"));
							prd.setNome(rsx.getString("nome"));
							prd.setDescrizione(rsx.getString("descrizione"));
							prd.setPrezzo(rsx.getInt("prezzo"));
						}
							
				//aggiunge prodotto all array
				listaProdotto.add(prd);
				}
				//aggiunge prodotto all ordine
				or.setProdotto(listaProdotto);
			}
			
		} finally {
			try {
				if (preparedStatement1 != null && preparedStatement2 != null && preparedStatement3 != null) {
					preparedStatement3.close();
					preparedStatement2.close();
					preparedStatement1.close();
				}
			} finally {
				if (conn != null)
					conn.close();
			}
		}
		return lista;
	}
//__________________________________________________________________________________________________
	//aggiorna lo stato di un ordine
	public synchronized void avanzaStato(String stato,int idOrdine) throws SQLException {
		Connection conn = null;
		PreparedStatement preparedStatement1 = null;
		String SQL1 = "update ordine set stato = ? where id = ? ";
		try {
			conn = getConnection();
			
			preparedStatement1 = conn.prepareStatement(SQL1);
			preparedStatement1.setString(1, stato);
			preparedStatement1.setInt(2, idOrdine);
			 preparedStatement1.executeUpdate();
	} finally {
		try {
			if (preparedStatement1 != null && preparedStatement1!= null) {
				
				preparedStatement1.close();
			}
		} finally {
			if (conn != null)
				conn.close();
		}
	}
}
	//______________________________________________________________________________________________
		//elimina ordine
	public synchronized boolean eliminaOrdine(int idOrdine) throws SQLException {
		Connection conn = null;
		PreparedStatement preparedStatement1 = null,preparedStatement2 = null;
		String SQL1 = "DELETE FROM ordine where id = ? ";
		String SQL2 = "select id FROM ordine where id = ? ";
		boolean eliminazione = false;
		try {
			conn = getConnection();
			preparedStatement2 = conn.prepareStatement(SQL2);
		    preparedStatement2.setInt(1, idOrdine);
			ResultSet rst = preparedStatement2.executeQuery();
					
			if(rst.next()) {
				System.out.println("ordine da cancellare: "+idOrdine);
					preparedStatement1 = conn.prepareStatement(SQL1);
					preparedStatement1.setInt(1, idOrdine);
					preparedStatement1.executeUpdate();
					
					eliminazione = true;
				
			}else {
				eliminazione=false;
			}
			
		}catch (SQLException e){
			eliminazione = false;
	} //finally {
		//try {
			//if (preparedStatement1 != null && preparedStatement2!= null) {
				//preparedStatement2.close();
				//preparedStatement1.close();
			//}
		//} 
		finally {
			if (conn != null)
				conn.close();
		}
	//}
		return eliminazione;
}
	
	
	//______________________________________________________________________________________________
		//aggiungi ordine
	
	public int creaOrdine(int idCarrello,String utente, Double prezzo) throws SQLException {
		Connection conn = null;
		PreparedStatement preparedStatement1 = null,preparedStatement2 = null,preparedStatement3 = null;
		//boolean ritorno = false;
		CarrelloModel carrelloModel = new CarrelloModel();
		Carrello cart = (Carrello)carrelloModel.returnCarrello(utente);
		String SQL1 ="insert into ordine (utenteOrdine,prezzoTotale,stato) values "+ "(?,?,'Da Spedire')";
		String SQL2 ="  select id from ordine where utenteOrdine = ? && stato = 'Da Spedire'  && iban is NULL;";
		String SQL3 ="insert into prodottiOrdine (idOrdine,idProdottoLista,numeroProdotto) values (?,?,?)";
		int id = 0 ;
		
		try {
			conn = getConnection();
			//crea ordine
			preparedStatement1 = conn.prepareStatement(SQL1);
			preparedStatement1.setString(1,utente);
			preparedStatement1.setDouble(2,prezzo);
			preparedStatement1.execute();
			//System.out.println("@1- db crea ordine :"+cart.getUtenteCarrello()+" - "+prezzo+" - da spedire");
			
			//trova id dell ordine
			preparedStatement2 = conn.prepareStatement(SQL2);
			preparedStatement2.setString(1,cart.getUtenteCarrello());
			ResultSet rst = preparedStatement2.executeQuery();
					
			if(rst.next()) {
				id= rst.getInt("id");
				}
			//System.out.println("@2- db id dell' ordine : "+id);
			
			//inserisce prodotti nell ordine
			ArrayList<Prodotto> lista = (ArrayList<Prodotto>)cart.getProdotto();
			
				for(Prodotto pr : lista ){
					//System.out.println("@3- db aggiungi prodotto all' ordine : "+id+" - "+ pr.getIdProdotto()+" - "+pr.getQuantita());
				//(idOrdine,idProdottoLista,numeroProdotto) 
			preparedStatement3 = conn.prepareStatement(SQL3);
			preparedStatement3.setInt(1,id);
			preparedStatement3.setInt(2,pr.getIdProdotto());
			preparedStatement3.setInt(3,pr.getQuantita());
			preparedStatement3.execute();
			//System.out.println("@3- db aggiungi prodotto all' ordine : "+id+" - "+ pr.getIdProdotto()+" - "+pr.getQuantita());
			//aggiungere elimina prodotto dal carrello
			// eliminaProdottoCarrello(int numerocarrello,int idProdotto)
			 carrelloModel.eliminaProdottoCarrello(idCarrello,pr.getIdProdotto());
			// System.out.println("@4 - db elimina dal carrello : "+idCarrello +" - "+pr.getIdProdotto());
			}
			
		}catch(SQLException e){
			e.printStackTrace();
		} finally {
			try {
				if (preparedStatement1 != null && preparedStatement2 != null && preparedStatement3 != null) {
					preparedStatement3.close();
					preparedStatement2.close();
					preparedStatement1.close();
				}
			} finally {
				if (conn != null)
					conn.close();
			}
		}
		
		return id ;
	}
	// __________________________________________________________________________________________________
		//inserisci iban
		public synchronized void inserisciIban(int idOrdine,String iban) throws SQLException {
			Connection conn = null;
			PreparedStatement preparedStatement1 = null;
			String SQL1 = "update ordine set iban = ? where id = ? ";
			try {
				conn = getConnection();
				
				preparedStatement1 = conn.prepareStatement(SQL1);
				preparedStatement1.setString(1, iban);
				preparedStatement1.setInt(2, idOrdine);
				 preparedStatement1.executeUpdate();
		} finally {
			try {
				if (preparedStatement1 != null && preparedStatement1!= null) {
					
					preparedStatement1.close();
				}
			} finally {
				if (conn != null)
					conn.close();
			}
		}
	}
	//___________________________________________________________________________________________________
	
	
}
