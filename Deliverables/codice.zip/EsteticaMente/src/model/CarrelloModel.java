package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import bean.Carrello;
import bean.Prodotto;

public class CarrelloModel{
	
		
		
		
		
		public Connection getConnection() throws SQLException {

		    Connection conn = null;
		    try {
		    	Class.forName("com.mysql.jdbc.Driver").newInstance();
		    	  String url = "jdbc:mysql://localhost/fiorazon1";
		    	  conn = DriverManager.getConnection(url, "root", "aurora96");
		    }catch(Exception e) {
		    	e.printStackTrace();
		    }
		    
		   // System.out.println("Connected to database");
		    return conn;
		}
// __________________________________________________________________________________________________
		//viasualizza carrello
		public synchronized Carrello returnCarrello(String User) throws SQLException {
			Connection conn = getConnection();
			PreparedStatement preparedStatement1 = null;
			Carrello cart = new Carrello();
			ArrayList<Prodotto> listaCarrello = new ArrayList<Prodotto>();
			
			String SQL1 = "select * from prodotto,carrello,prodottiCarrello "
					+ "where carrello.utenteCarrello = ? "
					+ "&& carrello.idCarrello = prodotticarrello.numerocarrello"
					+ " && prodotticarrello.idProdottoCarrello = prodotto.idProdotto;";
			
			
			try {
				conn = getConnection();
				preparedStatement1 = conn.prepareStatement(SQL1);
				preparedStatement1.setString(1, User);
				ResultSet rs = preparedStatement1.executeQuery();
				
				while(rs.next()) {
					cart.setIdCarrello(rs.getInt("idCarrello"));
					cart.setUtenteCarrello(User);
				Prodotto ptt = new Prodotto();
				ptt.setIdProdotto(rs.getInt("idProdotto"));
				ptt.setNome(rs.getString("nome"));
				ptt.setDescrizione(rs.getString("descrizione"));
				ptt.setUrlImmagine(rs.getString("urlImmagine"));
				ptt.setQuantita(rs.getInt("quantitaProdotto"));
				ptt.setPrezzo(rs.getDouble("prezzo"));
					listaCarrello.add(ptt);
				}
				cart.setProdotto(listaCarrello);
			} finally {
				try {
					if (preparedStatement1 != null && preparedStatement1 != null) {
						preparedStatement1.close();
					}
				} finally {
					if (conn != null)
						conn.close();
				}
			}
			return cart;
		}
//____________________________________________________________________________________________	
		//aggiungi al carrello
		public boolean aggiungiProdottoCarrello (String username, int idProdotto, int quantita) throws SQLException {
			
			
			Connection conn = null;
			PreparedStatement preparedStatement1 = null,preparedStatement2 = null,preparedStatement3 = null;
			boolean ritorno = false,v= false;
			int numerocarrello=0,quantitaesistente=0;
			String SQL0="select idCarrello from carrello where utentecarrello = ?";
			String SQL1 ="insert into prodotticarrello(numeroCarrello,idProdottoCarrello,quantitaProdotto)values(?,?,?)";
			String verifica ="select * from prodotticarrello where numerocarrello = ? && idProdottocarrello = ?";
			try {
				conn = getConnection();
				//trova id
				preparedStatement3 = conn.prepareStatement(SQL0);
				preparedStatement3.setString(1, username);
				ResultSet rst = preparedStatement3.executeQuery();
				if(rst.next()) {
					numerocarrello=(rst.getInt("idCarrello"));
					
					preparedStatement1 = conn.prepareStatement(SQL1);
					preparedStatement1.setInt(1,numerocarrello);
					preparedStatement1.setInt(2,idProdotto);
					preparedStatement1.setInt(3,quantita);
					preparedStatement1.execute();
					ritorno = true;
				}else{
					ritorno= false;
					
				}
				
				//verifica se esiste 
				preparedStatement2 = conn.prepareStatement(verifica);
				preparedStatement2.setInt(1, numerocarrello);
				preparedStatement2.setInt(2, idProdotto);
				ResultSet rs = preparedStatement2.executeQuery();
				if(rs.next()) {
					quantitaesistente = (rs.getInt("Quantitaprodotto"));
					v= true;	
				}else{
					v=false;
				}
			
				if(v == false){
				//caso non esiste
				preparedStatement1 = conn.prepareStatement(SQL1);
				preparedStatement1.setInt(1,numerocarrello);
				preparedStatement1.setInt(2,idProdotto);
				preparedStatement1.setInt(3,quantita);
				preparedStatement1.execute();
				ritorno = true;
				}
				
				if(v == true){
					//Quantita aggiornata 
					quantita = quantita + quantitaesistente;
					cambiaQuantitaCarrello( numerocarrello,  quantita,  idProdotto);
					ritorno = true;
				}
			} catch(SQLException e) {
				e.printStackTrace();
				} finally {
				try {
					if (preparedStatement1 != null && preparedStatement2 != null && preparedStatement3 != null) {
						preparedStatement2.close();
						preparedStatement1.close();
						preparedStatement3.close();

					}
				} finally {
					if (conn != null)
						conn.close();
				}
			}
			
			return ritorno ;
		}
			
//______________________________________________________________________________________________
		//cambia quantita
		public boolean cambiaQuantitaCarrello(int numerocarrello, int quantita, int idProdotto) throws SQLException {
			Connection conn = null;
			PreparedStatement preparedStatement1 = null;
			boolean ritorno = false;
			
			String SQL1 ="UPDATE prodotticarrello SET quantitaprodotto = ? WHERE  numeroCarrello = ? && idProdottoCarrello = ? ";

			try {
				conn = getConnection();
				preparedStatement1 = conn.prepareStatement(SQL1);
				preparedStatement1.setInt(1,quantita);
				preparedStatement1.setInt(2,numerocarrello);
				preparedStatement1.setInt(3,idProdotto);
				preparedStatement1.execute();
				ritorno = true;
				//System.out.println("db modifica quantita : "+numerocarrello+" - "+idProdotto+" - "+quantita);
			}catch(SQLException e){
				e.printStackTrace();
			} finally {
				try {
					if (preparedStatement1 != null && preparedStatement1 != null) {
						preparedStatement1.close();
					}
				} finally {
					if (conn != null)
						conn.close();
				}
			}
			
			return ritorno ;
		}
//_________________________________________________________________________________________________

		//crea carrello
		public boolean creaCarrello(String username) throws SQLException {
			Connection conn = null;
			PreparedStatement preparedStatement1 = null;
			boolean ritorno = false;
			
			String SQL1 ="insert into carrello(utenteCarrello) values (?)";
			System.out.println(username);
			try {
				conn = getConnection();
				preparedStatement1 = conn.prepareStatement(SQL1);
				preparedStatement1.setString (1,username);
				ritorno = true;
			} finally {
				try {
					if (preparedStatement1 != null && preparedStatement1 != null) {
						preparedStatement1.close();
					}
				} finally {
					if (conn != null)
						conn.close();
				}
			}
			
			return ritorno ;
		}
//_________________________________________________________________________________________________
		//elimina prodotto
				public boolean eliminaProdottoCarrello(int numerocarrello,int idProdotto) throws SQLException {
					Connection conn = null;
					PreparedStatement preparedStatement1 = null;
					boolean ritorno = false;
					
					String SQL1 ="delete from prodotticarrello  WHERE  numeroCarrello = ? && idProdottoCarrello = ?";

					try {
						conn = getConnection();
						preparedStatement1 = conn.prepareStatement(SQL1);
						preparedStatement1.setInt(1,numerocarrello);
						preparedStatement1.setInt(2,idProdotto);
						preparedStatement1.execute();
						ritorno = true;
					} finally {
						try {
							if (preparedStatement1 != null && preparedStatement1 != null) {
								preparedStatement1.close();
							}
						} finally {
							if (conn != null)
								conn.close();
						}
					}
					
					return ritorno ;
				}
//_________________________________________________________________________________________________
}
