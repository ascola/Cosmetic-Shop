package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import bean.Prodotto;

public class ProdottiModel {
	
	/*private static DataSource ds;

	static {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/esteticamente");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}*/
	
	public Connection getConnection() throws SQLException {

	    Connection conn = null;
	    try {
	    	Class.forName("com.mysql.jdbc.Driver").newInstance();
	    	  String url = "jdbc:mysql://localhost/fiorazon1";
	    	  conn = DriverManager.getConnection(url, "root", "aurora96");
	    }catch(Exception e) {
	    	e.printStackTrace();
	    }
	    
	    return conn;
	}
	
	//_________________________________________________________________________________________________
	
	//restituisce i prodotti
	public synchronized ArrayList<Prodotto> returnProdotti() throws SQLException {
		Connection conn = null;
		PreparedStatement preparedStatement1 = null;
		ArrayList<Prodotto> lista = new ArrayList<Prodotto>();
		
		String SQL1 = "select * from prodotto";
		
		try {
			conn = getConnection();
			preparedStatement1 = conn.prepareStatement(SQL1);
			
			ResultSet rs = preparedStatement1.executeQuery();
			while(rs.next()) {
				Prodotto pr = new Prodotto();
				pr.setIdProdotto(rs.getInt("idProdotto"));
				pr.setUrlImmagine(rs.getString("urlImmagine"));
				pr.setNome(rs.getString("nome"));
				pr.setQuantita(rs.getInt("quantita"));
				pr.setDescrizione(rs.getString("descrizione"));
				pr.setPrezzo(rs.getDouble("prezzo"));
				lista.add(pr);
			}

		} finally {
			try {
				if (preparedStatement1 != null && preparedStatement1 != null) {
					preparedStatement1.close();
				}
			} finally {
				if (conn != null)
					conn.close();
			}
		}
		return lista;
	}
//________________________________________________________________________________________________
	//inserisce un nuovo prodotto nel db
	public synchronized void insertProdotto(Prodotto prodotto) throws SQLException {
		Connection conn = null;
		PreparedStatement preparedStatement1 = null;
		
		String SQL1 = "insert into prodotto (urlImmagine,nome,quantita,descrizione,prezzo)values (?,?,?,?,?)";
		try {
			conn = getConnection();
			
			preparedStatement1 = conn.prepareStatement(SQL1);
				
			preparedStatement1.setString(1, prodotto.getUrlImmagine());
			preparedStatement1.setString(2, prodotto.getNome());
			preparedStatement1.setInt(3, prodotto.getQuantita());
			preparedStatement1.setString(4, prodotto.getDescrizione());
			preparedStatement1.setDouble(5, prodotto.getPrezzo());
				
			preparedStatement1.executeUpdate();
	
		}catch (SQLException e){			
			e.printStackTrace();
			
		} finally {
			try {
				if (preparedStatement1 != null ) {
					preparedStatement1.close();
				}
			} finally {
				//if (conn != null)
					conn.close();
			}
		} 
		
	
	}
	//________________________________________________________________________________________________
	
	public synchronized boolean eliminaProdotto (String idProdotto) throws SQLException {
		Connection conn = null;
		PreparedStatement preparedStatement1 = null;
		String selectSQL = "DELETE FROM Prodotto WHERE idProdotto = ?";
		boolean eliminazione = false;
		try {
			conn = getConnection();
			preparedStatement1 = conn.prepareStatement(selectSQL);
			preparedStatement1.setString(1, idProdotto);
				preparedStatement1.executeUpdate();
				eliminazione =true;
		}catch (SQLException e){
				eliminazione = false;
		} finally {
			try {
				if (preparedStatement1 != null ) {
					preparedStatement1.close();
				}
			} finally {
				if (conn != null)
					conn.close();
			}
		}
		return eliminazione; 
	}
	//_________________________________________________________________________________________________
			//modifica immagine del prodotto
	public synchronized void modificaImmagine (int idProdotto,String url) throws SQLException {
		Connection conn = null;
		PreparedStatement preparedStatement1 = null;
		String selectSQL = "UPDATE prodotto SET urlImmagine = ? WHERE idProdotto = ?";
		
		try {
			conn = getConnection();
			preparedStatement1 = conn.prepareStatement(selectSQL);
			preparedStatement1.setString(1, url);
			preparedStatement1.setInt(2, idProdotto);
				preparedStatement1.executeUpdate();
		
		} finally {
			try {
				if (preparedStatement1 != null ) {
					preparedStatement1.close();
				}
			} finally {
				if (conn != null)
					conn.close();
			}
		}
		
	}
	//_________________________________________________________________________________________________
	//modifica prodotto
public synchronized void modificaProdotto (int idProdotto,Prodotto prodotto) throws SQLException {
	Connection conn = null;
	PreparedStatement preparedStatement1 = null;
	String selectSQL = "UPDATE prodotto SET nome = ?,quantita = ?,descrizione = ?,prezzo = ? WHERE idProdotto = ?";
	
	try {
		conn = getConnection();
		preparedStatement1 = conn.prepareStatement(selectSQL);
		preparedStatement1.setString(1, prodotto.getNome());
		preparedStatement1.setInt(2, prodotto.getQuantita());
		preparedStatement1.setString(3, prodotto.getDescrizione());
		preparedStatement1.setDouble(4, prodotto.getPrezzo());
		preparedStatement1.setInt(5, idProdotto);
			preparedStatement1.executeUpdate();
	
	} finally {
		try {
			if (preparedStatement1 != null ) {
				preparedStatement1.close();
			}
		} finally {
			if (conn != null)
				conn.close();
		}
	}
	
	
}
//_________________________________________________________________________________________________

	public synchronized Prodotto returnInfo (int idProdotto) throws SQLException {
		Connection conn = null;
		PreparedStatement preparedStatement1 = null;
		String selectSQL = "select * from prodotto where idProdotto = ?";
		Prodotto prd = new Prodotto();
		try {
			conn = getConnection();
			preparedStatement1 = conn.prepareStatement(selectSQL);
			preparedStatement1.setInt(1, idProdotto);
		ResultSet rs = preparedStatement1.executeQuery();
			if(rs.next()) {	
				
				prd.setIdProdotto(rs.getInt("idProdotto"));
				prd.setNome(rs.getString("nome"));
				prd.setPrezzo(rs.getDouble("prezzo"));
				prd.setQuantita(rs.getInt("quantita"));
				prd.setDescrizione(rs.getString("descrizione"));
			}
		
		} finally {
			try {
				if (preparedStatement1 != null ) {
					preparedStatement1.close();
				}
			} finally {
				if (conn != null)
					conn.close();
			}
		}
		return prd;
	}
	//_________________________________________________________________________________________________
	//funzione ricerca
	public ArrayList<Prodotto> ricerca(int numero,String nome) throws SQLException {
		Connection conn = null;
		PreparedStatement preparedStatement1 = null;
		ArrayList<Prodotto> lista  = new ArrayList<Prodotto>();
		String SQL1 =null;
		
		switch(numero){
		case 1 : SQL1 ="select * from prodotto where nome >= ? order by nome asc";
			break;
		case 2 : SQL1 ="select * from prodotto where nome >= ? order by nome desc";
			break;
		case 3 : SQL1 ="select * from prodotto where nome >= ? order by prezzo asc";
			break;
		case 4 : SQL1 ="select * from prodotto where nome >= ? order by prezzo desc";
			break;
		}
		try {
			conn = getConnection();
			preparedStatement1 = conn.prepareStatement(SQL1);
			preparedStatement1.setString (1,nome);
			ResultSet rs = preparedStatement1.executeQuery();
			while(rs.next()) {
				Prodotto pr = new Prodotto();
				pr.setIdProdotto(rs.getInt("idProdotto"));
				pr.setUrlImmagine(rs.getString("urlImmagine"));
				pr.setNome(rs.getString("nome"));
				pr.setQuantita(rs.getInt("quantita"));
				pr.setDescrizione(rs.getString("descrizione"));
				pr.setPrezzo(rs.getDouble("prezzo"));
				lista.add(pr);
			}
		} finally {
			try {
				if (preparedStatement1 != null && preparedStatement1 != null) {
					preparedStatement1.close();
				}
			} finally {
				if (conn != null)
					conn.close();
			}
		}
		
		return lista ;
	}
	//______________________________________________________________________________________________
}
