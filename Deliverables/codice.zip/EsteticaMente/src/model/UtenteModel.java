package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import bean.Utente;

public class UtenteModel {
	
	public Connection getConnection() throws SQLException {

	    Connection conn = null;
	    try {
	    	Class.forName("com.mysql.jdbc.Driver").newInstance();
	    	  String url = "jdbc:mysql://localhost/fiorazon1";
	    	  conn = DriverManager.getConnection(url, "root", "aurora96");
	    }catch(Exception e) {
	    	e.printStackTrace();
	    }
	    
	    //System.out.println("Connected to database");
	    return conn;
	}
//__________________________________________________________________________________________________
	public synchronized Utente returnInfo(String username) throws SQLException {
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		Utente usr = new Utente();
		
		String selectSQL = "select * from utente where username = ?";
		
		try {
			conn = getConnection();
			preparedStatement = conn.prepareStatement(selectSQL);
			preparedStatement.setString(1, username);

			ResultSet rs = preparedStatement.executeQuery();
			
			while(rs.next()) {
				usr.setRuolo(rs.getString("ruolo"));
				usr.setNome(rs.getString("nome"));
				usr.setCognome(rs.getString("cognome"));
				usr.seteMail(rs.getString("eMail"));
				usr.setCodiceFiscale(rs.getString("codiceFiscale"));
				usr.setDataNascita(rs.getString("dataNascita"));
				usr.setCittaNascita(rs.getString("cittaNascita"));
				usr.setCittaResidenza(rs.getString("cittaResidenza"));
				usr.setVia(rs.getString("via"));
				usr.setNumeroCivico(rs.getInt("numeroCivico"));
				usr.setCap(rs.getInt("cap"));
				usr.setUsername(rs.getString("username"));
				usr.setPassword(rs.getString("password"));
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (conn != null)
					conn.close();
			}
		}
		return usr;
	}
	//__________________________________________________________________________________________
	public synchronized boolean controllUser(String username) throws SQLException {
		Connection conn = null;
		PreparedStatement preparedStatement1 = null;
		String selectSQL = "select username from utente where username = ?";
		
		try {
			conn = getConnection();
			preparedStatement1 = conn.prepareStatement(selectSQL);
			preparedStatement1.setString(1, username);
			
			ResultSet rs = preparedStatement1.executeQuery();
			if(rs.next() == true) {
				return true;
			}else{
				return false;
			}
			
			

		} finally {
			try {
				if (preparedStatement1 != null ) {
					preparedStatement1.close();
				}
			} finally {
				if (conn != null)
					conn.close();
			}
		} 
	}
//______________________________________________________________________________________
	public synchronized void modificaUtente(Utente user,String username) throws SQLException {
		Connection conn = null;

		PreparedStatement preparedStatement5 = null;
		
		String SQL5 = " UPDATE utente SET nome = ?, cognome = ?, eMail = ?, codiceFiscale = ?,"
				+ " dataNascita = ?, cittaNascita = ?, cittaResidenza = ?, via = ?, numeroCivico = ?,"
				+ " cap = ?, password = MD5(?) WHERE username = ?";
		
		
		try {
			conn = getConnection();
									
									
								preparedStatement5 = conn.prepareStatement(SQL5);
								preparedStatement5.setString(1, user.getNome());
								preparedStatement5.setString(2, user.getCognome());
								preparedStatement5.setString(3, user.geteMail());
								preparedStatement5.setString(4, user.getCodiceFiscale());
								preparedStatement5.setString(5, user.getDataNascita());
								preparedStatement5.setString(6, user.getCittaNascita());
								preparedStatement5.setString(7, user.getCittaResidenza());
								preparedStatement5.setString(8, user.getVia());
								preparedStatement5.setInt(9, user.getNumeroCivico());
								preparedStatement5.setInt(10, user.getCap());
								preparedStatement5.setString(11, user.getPassword());
								preparedStatement5.setString(12, username);
									preparedStatement5.execute();
									
			} finally {
			try {
				if (preparedStatement5 != null ) {
					preparedStatement5.close();
				}
			} finally {
				if (conn != null)
					conn.close();
				
			}
		} 
	}
//_________________________________________________________________________________________________
	//devo ridimensionare file era stato modificato ma le modifiche sono andate perse
	public synchronized boolean eliminaUtente(String username) throws SQLException {
		Connection conn = null;
		
		PreparedStatement preparedStatement7 = null, preparedStatement8=null;
		boolean eliminazione= false;
		
		String SQL7 = " DELETE FROM utente WHERE username = ?";
		
		String SQL8 = "select * from utente where username =?";
		
		
	
		
		try {
			conn = getConnection();
			
			preparedStatement8 = conn.prepareStatement(SQL8);
			preparedStatement8.setString(1, username);
			ResultSet rsCheck = preparedStatement8.executeQuery();
			if(!rsCheck.next()) {
				eliminazione = false;
			}else {
			
			preparedStatement7 = conn.prepareStatement(SQL7);
			preparedStatement7.setString(1, username);
			//preparedStatement7.setString(2, "utente");
				preparedStatement7.executeUpdate();
				
				eliminazione= true;
			}
				
		}catch (SQLException e){
			e.printStackTrace();
			eliminazione = false;
			
			} finally {
			try {
				
										if (preparedStatement7 != null ) {
											preparedStatement7.close();
										}
									
			} finally {
				if (conn != null)
					conn.close();
				
			}
		} 
		
		return eliminazione;
	}
//__________________________________________________________________________________________________
	public synchronized void modificaAccount(Utente user,String username) throws SQLException {
		Connection conn = null;
		
		PreparedStatement preparedStatement5 = null;
		
		String SQL5 = " UPDATE utente SET nome = ?, cognome = ?, eMail = ?, codiceFiscale = ?,"
				+ " dataNascita = ?, cittaNascita = ?, cittaResidenza = ?, via = ?, numeroCivico = ?,"
				+ " cap = ?, username = ?, password = MD5(?) WHERE username = ?";
		
		try {
			conn = getConnection();
			
							//modifica di utente
								preparedStatement5 = conn.prepareStatement(SQL5);
								preparedStatement5.setString(1, user.getNome());
								preparedStatement5.setString(2, user.getCognome());
								preparedStatement5.setString(3, user.geteMail());
								preparedStatement5.setString(4, user.getCodiceFiscale());
								preparedStatement5.setString(5, user.getDataNascita());
								preparedStatement5.setString(6, user.getCittaNascita());
								preparedStatement5.setString(7, user.getCittaResidenza());
								preparedStatement5.setString(8, user.getVia());
								preparedStatement5.setInt(9, user.getNumeroCivico());
								preparedStatement5.setInt(10, user.getCap());
								preparedStatement5.setString(11, user.getUsername());
								preparedStatement5.setString(12, user.getPassword());
								preparedStatement5.setString(13, username);
									preparedStatement5.executeUpdate();
									
									
		}catch (SQLException e){
			//System.out.println("Info sulla SQLException:\n");
			e.printStackTrace();
			/*while (e != null) {
			System.out.println("Message:" + e.getMessage ());
			System.out.println("SQLState:" + e.getSQLState ());
			System.out.println("ErrorCode:" + e.getErrorCode ());
			e = e.getNextException();
				}*/
			} finally {
			try {
				
								if (preparedStatement5 != null ) {
									preparedStatement5.close();
									} 
			} finally {
				if (conn != null)
					conn.close();
				
			}
		} 
	}
	//_________________________________________________________________________________________________
	public synchronized String verifyAccess(String username, String password) throws SQLException {
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		
		//variabili
		String ruolo = null;
		
		String selectSQL = "select ruolo from utente where username = ? and password = MD5(?) ";
		
		try {
			conn = getConnection();
			preparedStatement = conn.prepareStatement(selectSQL);
			preparedStatement.setString(1, username);
			preparedStatement.setString(2, password);

			ResultSet rs = preparedStatement.executeQuery();
			
			while(rs.next()) {
				ruolo = rs.getString("ruolo");
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (conn != null)
					conn.close();
			}
		}
		return ruolo;
	}
	//_________________________________________________________________________________________________
	public synchronized void InsertUser(Utente user) throws SQLException {
		Connection conn = null;
		PreparedStatement preparedStatement1 = null, preparedStatement2 = null,preparedStatement3 = null;
		
		String insertSQL = "insert into utente (ruolo,nome,cognome,eMail,codiceFiscale,dataNascita,"
				+ "cittaNascita,cittaResidenza,via,numeroCivico,cap,username,password)"
				+ "values(?,?,?,?,?,?,?,?,?,?,?,?,MD5(?))";
		String selectSQL = "select username from utente where username = ?";
		String carrelloSQL ="insert into carrello(utentecarrello) values  (?)";
		try {
			conn = getConnection();
			preparedStatement1 = conn.prepareStatement(selectSQL);
			preparedStatement1.setString(1, user.getUsername());
			
			ResultSet rs = preparedStatement1.executeQuery();
			if(rs.next() == true) {
				throw new SQLException();
				
			}

			preparedStatement2 = conn.prepareStatement(insertSQL);
			preparedStatement2.setString(1, user.getRuolo());
			preparedStatement2.setString(2, user.getNome());
			preparedStatement2.setString(3, user.getCognome());
			preparedStatement2.setString(4, user.geteMail());
			preparedStatement2.setString(5, user.getCodiceFiscale());
			preparedStatement2.setString(6, user.getDataNascita());
			preparedStatement2.setString(7, user.getCittaNascita());
			preparedStatement2.setString(8, user.getCittaResidenza());
			preparedStatement2.setString(9, user.getVia());
			preparedStatement2.setInt(10, user.getNumeroCivico());
			preparedStatement2.setInt(11, user.getCap());
			preparedStatement2.setString(12, user.getUsername());
			preparedStatement2.setString(13, user.getPassword());
			
			preparedStatement2.executeUpdate();
			
			//System.out.println("creato utente");
			preparedStatement3 = conn.prepareStatement(carrelloSQL);
			preparedStatement3.setString (1,(String)user.getUsername());
			preparedStatement3.executeUpdate();
			//System.out.println("creato carrello "+usr.getUsername());
		}catch(SQLException e){
			e.printStackTrace();
		} finally {
			try {
				if (preparedStatement1 != null && preparedStatement2 != null && preparedStatement3 != null) {
					preparedStatement3.close();
					preparedStatement2.close();
					preparedStatement1.close();
				}
			} finally {
				if (conn != null)
					conn.close();
			}
		} 
	}
	//__________________________________________________________________________________________
}
