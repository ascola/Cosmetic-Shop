package beanTest;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import bean.Carrello;
import bean.Prodotto;

class CarrelloTest {
	
	Carrello carrello;
	ArrayList<Prodotto> prodotti = new ArrayList<Prodotto>();

	@BeforeEach
	void setUp() throws Exception {
		carrello = new Carrello("test", 1, prodotti);
		assertNotNull(carrello);
	}

	@AfterEach
	void tearDown() throws Exception {
	
	}



	@Test
	final void testGetUtenteCarrello() {
		String test = "test";
		String carrelloUser = carrello.getUtenteCarrello();
		assertEquals(test,carrelloUser);
	}

	@Test
	final void testGetProdotto() {
		
		assertNotNull(carrello.getProdotto());
		
	}

	@Test
	final void testGetIdCarrello() {
		assertNotNull(carrello.getIdCarrello());
	}

	@Test
	final void testSetUtenteCarrello() {
		
		carrello.setUtenteCarrello("test1");
		String nome = carrello.getUtenteCarrello();
		assertEquals("test1", nome);
	}

	@Test
	final void testSetProdotto() {
		ArrayList<Prodotto> prodotti1 = new ArrayList<Prodotto>();
		carrello.setProdotto(prodotti1);
		assertNotSame(carrello.getProdotto(), prodotti);
	}

	@Test
	final void testSetIdCarrello() {
		int id = 4;
		carrello.setIdCarrello(id);
		assertEquals(id, carrello.getIdCarrello());
	}


}
