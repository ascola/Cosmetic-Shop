package beanTest;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import bean.Ordine;
import bean.Prodotto;

class OrdineTest {
	
	Ordine ordine;
	ArrayList<Prodotto> prodotti = new ArrayList<Prodotto>();

	@BeforeEach
	void setUp() throws Exception {
		ordine = new Ordine("test", "abcd14efghi33", "test", 30.0, 4, prodotti);
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	final void testOrdine() {
		
		assertNotNull(ordine);
	}



	@Test
	final void testGetUtenteOrdine() {
		assertNotNull(ordine.getUtenteOrdine());
	}

	@Test
	final void testGetStato() {
		assertNotNull(ordine.getStato());
	}

	@Test
	final void testGetPrezzoTotale() {
		assertNotNull(ordine.getPrezzoTotale());
	}

	@Test
	final void testGetId() {
		assertNotNull(ordine.getId());
	}

	@Test
	final void testGetProdotto() {
		assertNotNull(ordine.getProdotto());
	}

	@Test
	final void testGetIban() {
		assertNotNull(ordine.getIban());
	}

	@Test
	final void testSetUtenteOrdine() {
		ordine.setUtenteOrdine("utente2");
		assertEquals("utente2", ordine.getUtenteOrdine());
	}

	@Test
	final void testSetStato() {
		ordine.setStato("stato");
		assertEquals("stato", ordine.getStato());
	}

	@Test
	final void testSetPrezzoTotale() {
		ordine.setPrezzoTotale(33.3);
		assertEquals(33.3,ordine.getPrezzoTotale());
	}

	@Test
	final void testSetId() {
		ordine.setId(10);
		assertEquals(10, ordine.getId());
	}

	@Test
	final void testSetProdotto() {
		ArrayList<Prodotto> prodotti1 = new ArrayList<Prodotto>();
		ordine.setProdotto(prodotti1);
		assertNotSame(prodotti1, prodotti);
	}

	@Test
	final void testSetIban() {
		ordine.setIban("000000");
		assertEquals("000000", ordine.getIban());
	}

}
