package modelTest;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.junit.After;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

//import com.mysql.jdbc.PreparedStatement;
import model.CarrelloModel;



class CarrelloModelTest {
	
	
	
	Connection conn = null;
	CarrelloModel carrelloModel=null;
	String username;
	int idOrdine = 0;
	int idProdotto = 0;
	int idCarrello = 0;
	
	@Test
	final void testGetConnection() throws SQLException {
		assertNotNull(carrelloModel.getConnection());
	}

	@BeforeEach
	void setUp() throws Exception {
		
		carrelloModel = new CarrelloModel();
		conn = carrelloModel.getConnection();
		
		//creo un nuovo prodotto di test
				String prodottoSQL = "insert into prodotto (urlImmagine,nome,quantita,descrizione,prezzo)values ('test.jpg','prodottoTest',"
						+ "50,'test',10.99)";
				PreparedStatement psProdotto = (PreparedStatement) conn.prepareStatement(prodottoSQL);
				psProdotto.executeUpdate();
				
				//prendo l'id del prodotto appena creato
				String idProdottoSQL = "select idProdotto from prodotto where nome='prodottoTest'";
				PreparedStatement psIdProdotto = (PreparedStatement) conn.prepareStatement(idProdottoSQL);
				ResultSet rsp = psIdProdotto.executeQuery();
				while(rsp.next())
					idProdotto=rsp.getInt(1);
				
				
				
				//Inserisco un utente fittizio
				String insertSQL = "insert into utente (ruolo,nome,cognome,eMail,codiceFiscale,dataNascita,"
						+ "cittaNascita,cittaResidenza,via,numeroCivico,cap,username,password)"
						+ "values('utente','test','test','test','test','test','test','test','test',1,10,'userTest', MD5('test'))";
				PreparedStatement preparedStatement0 = (PreparedStatement) conn.prepareStatement(insertSQL);
				preparedStatement0.executeUpdate();
				
				
				//creo il carrello relativo all'utente fittizio
				/*String carrelloSQL ="insert into carrello(utentecarrello) values  ('userTest')";
				PreparedStatement ps5 = (PreparedStatement) conn.prepareStatement(carrelloSQL);		
				ps5.executeUpdate();
				
				
				//prendo il riferimento all'id del carrello appena creato
				String idCarrelloSQL = "select idCarrello from carrello where utentecarrello = 'userTest'";
				PreparedStatement ps7 = (PreparedStatement) conn.prepareStatement(idCarrelloSQL);		
				ResultSet rs = ps7.executeQuery();
				
				while(rs.next()) {
					idCarrello = rs.getInt(1);
				}
		*/
	}
			
		

	@AfterEach
	void tearDown() throws Exception {
		//cancello i riferimenti ai test nel db
				String SQL4 ="delete from prodotticarrello where numeroCarrello=?";
				PreparedStatement ps8 = (PreparedStatement) conn.prepareStatement(SQL4);
				ps8.setInt(1, idCarrello);
				ps8.executeUpdate();
				
				
				String carrelloSQL ="delete from carrello where utentecarrello='userTest'";
				PreparedStatement ps5 = (PreparedStatement) conn.prepareStatement(carrelloSQL);		
				ps5.executeUpdate();
				
				
				String utenteSQL ="delete from utente where username='userTest'";
				PreparedStatement ps7 = (PreparedStatement) conn.prepareStatement(utenteSQL);		
				ps7.executeUpdate();
				
				String elimProdottoSQL ="delete from prodotto where idProdotto="+idProdotto+"";
				PreparedStatement ps10 = (PreparedStatement) conn.prepareStatement(elimProdottoSQL);		
				ps10.executeUpdate();
	}

	@Test
	final void testReturnCarrello() throws SQLException {
		assertNotNull(carrelloModel.returnCarrello("userTest"));
	}
	
	

	@Test
	final void testAggiungiProdottoCarrello() throws SQLException {
	
		int quantita = 13;
		
		carrelloModel.aggiungiProdottoCarrello("userTest", idProdotto, quantita);
		
		//inserimento prodotto con id sbagliato
		assertEquals(false,carrelloModel.aggiungiProdottoCarrello("userTest", 800000, quantita));
		
		
		//controllo se effettivamente � stata inserita la corretta quantita di prodotto di test
		String SQL = "select count(quantitaProdotto) as quantitaProdottoAggiunta from prodottiCarrello where idProdottoCarrello="+idProdotto+"";
		PreparedStatement psProdotto = (PreparedStatement) conn.prepareStatement(SQL);
		ResultSet rsp = psProdotto.executeQuery();
		int count = 0;
		while(rsp.next())
			count=rsp.getInt("quantitaProdottoAggiunta");
		
		
		assertEquals(13, quantita);
		
	}

	@Test
	final void testCambiaQuantitaCarrello() throws SQLException {
		int quantita = 22;

		carrelloModel.cambiaQuantitaCarrello(idCarrello, quantita, idProdotto);
		
		
		//controllo se effettivamente � stata cambiata la corretta quantita di prodotto di test
				String SQL = "select count(quantitaProdotto) as quantitaProdottoAggiunta from prodottiCarrello where idProdottoCarrello="+idProdotto+"";
				PreparedStatement psProdotto = (PreparedStatement) conn.prepareStatement(SQL);
				ResultSet rsp = psProdotto.executeQuery();
				int count = 0;
				while(rsp.next())
					count=rsp.getInt("quantitaProdottoAggiunta");
				
				
				assertEquals(22, quantita);
	}

	@Test
	final void testCreaCarrello() throws SQLException {
		
		carrelloModel.creaCarrello("userTest");
		
		//controllo che effettivamente sia stato creato il carrello
		String idCarrelloSQL = "select idCarrello from carrello where utentecarrello = 'userTest'";
		PreparedStatement ps7 = (PreparedStatement) conn.prepareStatement(idCarrelloSQL);		
		ResultSet rs = ps7.executeQuery();
		int riferimentoCarrelloCreato = 0;
		while(rs.next()) {
			riferimentoCarrelloCreato = rs.getInt(1);
		}	
		
		assertNotNull(riferimentoCarrelloCreato);
		
	}

	@Test
	final void testEliminaProdottoCarrello() throws SQLException {
		
		carrelloModel.eliminaProdottoCarrello(idCarrello, idProdotto);
		
		//controllo se effettivamente � stato eliminato il prodotto di test dal carrello e la query quindi deve restituire 0
		String SQL = "select count(quantitaProdotto) as prodottoEliminato from prodottiCarrello where idProdottoCarrello="+idProdotto+"";
		PreparedStatement psProdotto = (PreparedStatement) conn.prepareStatement(SQL);
		ResultSet rsp = psProdotto.executeQuery();
		int count = 0;
		while(rsp.next())
			count=rsp.getInt("prodottoEliminato");
		
		assertEquals(0, count);
		
	}

}
