package modelTest;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.*;

//import com.mysql.jdbc.PreparedStatement;

import bean.Prodotto;
import model.ProdottiModel;

class ProdottiModelTest {
	
	
	Connection conn = null;
	ProdottiModel prodottoModel;
	Prodotto prodotto = null;
	
	


	@BeforeEach
	void setUp() throws Exception {
		prodottoModel= new ProdottiModel();
		
		conn = prodottoModel.getConnection();
		
		
		//Inserisco un prodotto di test
		String SQL1 = "insert into prodotto (urlImmagine,nome,quantita,descrizione,prezzo)values ('test.jpg',"
				+ "'prodottoTest',90,'test',99.99)";
		PreparedStatement query = (PreparedStatement) conn.prepareStatement(SQL1);
		query.executeUpdate();
		
		
	}

	@AfterEach
	void tearDown() throws Exception {
		
		//cancello a valle di ogni test il prodotto di test
		String SQL1 = "delete from prodotto where nome='prodottoTest'";
		PreparedStatement query = (PreparedStatement) conn.prepareStatement(SQL1);
		query.executeUpdate();
		
		conn.close();
	}
	
	@Test
	final void testGetConnection() throws SQLException {
		assertNotNull(prodottoModel.getConnection());
	}


	@Test
	final void testReturnProdotti() throws SQLException {
		assertNotNull(prodottoModel.returnProdotti());
	}

	@Test
	final void testInsertProdotto() throws SQLException {
		//Cancello il prodotto del setUp
		String SQL1 = "delete from prodotto where nome='prodottoTest'";
		PreparedStatement query1 = (PreparedStatement) conn.prepareStatement(SQL1);
		query1.executeUpdate();
		
		
		//creo un nuovo prodotto di test da inserire e passare al metodo
		prodotto = new Prodotto(
				"test.jpg",
				"prodottoTestInserimento", 20, "test", 20.0);
		
		prodottoModel.insertProdotto(prodotto);
		
		//controllo se esiste il prodotto inserito
		
		String SQL = "select count(*) from prodotto where nome='prodottoTestInserimento'";
		PreparedStatement query = (PreparedStatement) conn.prepareStatement(SQL);
		ResultSet rs = query.executeQuery();
		int total=0;
		while(rs.next()) {
			total=rs.getInt(1);
		}
		
		//assertEquals(true, prodottoModel.InsertProdotto(prodotto));
		assertEquals(1, total);
		
		
		//cancello il prodotto modificato dal db
		String SQL2 = "delete from prodotto where nome='prodottoTestInserimento'";
		PreparedStatement query2 = (PreparedStatement) conn.prepareStatement(SQL2);
		query2.executeUpdate();
	}
	
	
	@Test
	final void testModificaImmagine() throws SQLException {
		//prendo l'id del prodotto di test a cui vogliamo cambiare l'immagine
		String SQL = "select idProdotto from prodotto where nome='prodottoTest'";
		PreparedStatement query = (PreparedStatement) conn.prepareStatement(SQL);
		ResultSet rs = query.executeQuery(SQL);
		int id=0;
		while(rs.next()) {
			id=rs.getInt("idProdotto");
		}
		
		prodottoModel.modificaImmagine(id, "test1.jpg");
		
		
		//controllo se l'immagine � stata modificata
		String SQL1 = "select urlImmagine from prodotto where nome ='prodottoTest'";
		PreparedStatement query2 = (PreparedStatement) conn.prepareStatement(SQL1);
		ResultSet rs1 = query2.executeQuery(SQL1);
		String img="";
		while(rs1.next()) {
			img = rs1.getString("urlImmagine");
		}
		
		assertEquals("test1.jpg", img);
	}
	
	
	@Test
	final void testModificaProdotto() throws SQLException {
		
		//creo il prodotto da passare come modifica al metodo
		Prodotto prodotto2 = new Prodotto("testModifica2", 50, "test2", 50.00);
		
		//prendo l'id del prodotto di test da modificare
		String SQL = "select idProdotto from prodotto where nome='prodottoTest'";
		PreparedStatement query = (PreparedStatement) conn.prepareStatement(SQL);
		ResultSet rs = query.executeQuery(SQL);
		int id=0;
		while(rs.next()) {
			id=rs.getInt("idProdotto");
		}
		
		
		prodottoModel.modificaProdotto(id, prodotto2);
		
		//controllo se il prodotto � stato modificato
		String SQL1 = "select descrizione from prodotto where nome='testModifica2'";
		PreparedStatement query1 = (PreparedStatement) conn.prepareStatement(SQL1);
		ResultSet rs1 = query1.executeQuery(SQL1);
		String descr = "";
		while(rs1.next()) {
			descr=rs1.getString("descrizione");
		}
		
		assertEquals("test2", descr);
		
		
		//cancello il prodotto modificato
		String SQL2 = "delete from prodotto where nome='testModifica2'";
		PreparedStatement query2 = (PreparedStatement) conn.prepareStatement(SQL2);
		query2.executeUpdate();
		
	}

	@Test
	final void testReturnInfo() throws SQLException {
		
		//prendo l'id del prodotto di test 
				String SQL = "select idProdotto from prodotto where nome='prodottoTest'";
				PreparedStatement query = (PreparedStatement) conn.prepareStatement(SQL);
				ResultSet rs = query.executeQuery();
				int id=0;
				while(rs.next()) {
					id=rs.getInt(1);
				}
				
		assertNotNull(id);
	}

	@Test
	final void testRicerca() throws SQLException {
		int paramRicerca = 1;
		assertNotNull(prodottoModel.ricerca(paramRicerca, "prodottoTest"));
	}
	
	@Test
	final void testEliminaProdotto() throws SQLException {
		//prendo l'id del prodotto di test
		String SQL = "select idProdotto from prodotto where nome='prodottoTest'";
		PreparedStatement query = (PreparedStatement) conn.prepareStatement(SQL);
		ResultSet rs = query.executeQuery(SQL);
		int id=0;
		while(rs.next()) {
			id=rs.getInt("idProdotto");
		}
		
		
		prodottoModel.eliminaProdotto(Integer.toString(id));
		
		
		//controllo se esiste ancora il prodotto nel db
		String SQL1 = "select count(*) as prodottoEliminato from prodotto where nome='prodottoTest'";
		PreparedStatement query1 = (PreparedStatement) conn.prepareStatement(SQL1);
		ResultSet rsId = query1.executeQuery(SQL1);
		int prodottoDopoEliminazione = 0;
		while(rsId.next()) {
		prodottoDopoEliminazione=rsId.getInt("prodottoEliminato");
		}
		
		assertEquals(0, prodottoDopoEliminazione);
	}


}
