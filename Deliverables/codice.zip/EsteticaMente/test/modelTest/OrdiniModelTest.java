package modelTest;

import static org.junit.jupiter.api.Assertions.*;
import java.sql.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

//import com.mysql.jdbc.Connection;
//import com.mysql.jdbc.PreparedStatement;

import model.CarrelloModel;
import model.OrdiniModel;

class OrdiniModelTest {
	
	Connection conn = null;
	int idTest;
	
	int idOrdine = 0;
	int idProdotto = 0;
	int idCarrello = 0;
	OrdiniModel ordineModel = new OrdiniModel();

	@BeforeEach
	void setUp() throws Exception {
		conn = (Connection) ordineModel.getConnection();
		
		
		//creo un nuovo prodotto
		String prodottoSQL = "insert into prodotto (urlImmagine,nome,quantita,descrizione,prezzo)values ('test.jpg','prodottoTest',"
				+ "50,'test',10.99)";
		PreparedStatement psProdotto = (PreparedStatement) conn.prepareStatement(prodottoSQL);
		psProdotto.executeUpdate();
		
		//prendo l'id del prodotto appena creato
		String idProdottoSQL = "select idProdotto from prodotto where nome='prodottoTest'";
		PreparedStatement psIdProdotto = (PreparedStatement) conn.prepareStatement(idProdottoSQL);
		ResultSet rsp = psIdProdotto.executeQuery();
		while(rsp.next())
			idProdotto=rsp.getInt(1);
		
		
		
		//Inserisco un utente fittizio
		String insertSQL = "insert into utente (ruolo,nome,cognome,eMail,codiceFiscale,dataNascita,"
				+ "cittaNascita,cittaResidenza,via,numeroCivico,cap,username,password)"
				+ "values('utente','test','test','test','test','test','test','test','test',1,10,'userTest', MD5('test'))";
		PreparedStatement preparedStatement0 = (PreparedStatement) conn.prepareStatement(insertSQL);
		preparedStatement0.executeUpdate();
		
		//creo il carrello relativo all'utente fittizio
		String carrelloSQL ="insert into carrello(utentecarrello) values  ('userTest')";
		PreparedStatement ps5 = (PreparedStatement) conn.prepareStatement(carrelloSQL);		
		ps5.executeUpdate();
		
		
		//Aggiungo dei prodotti al carrello relativo all'utente fittizio:
		//-prendo l'id del carrello dell'utente
		String idCarrelloSQL = "select idCarrello from carrello where utentecarrello = 'userTest'";
		PreparedStatement ps7 = (PreparedStatement) conn.prepareStatement(idCarrelloSQL);		
		ResultSet rs = ps7.executeQuery();
		
		while(rs.next()) {
			idCarrello = rs.getInt(1);
		}
		
		//-inserisco un 5 prodotti di test nel carrello di test
		String SQL4 ="insert into prodotticarrello(numeroCarrello,idProdottoCarrello,quantitaProdotto)values(?,?,5)";
		PreparedStatement ps8 = (PreparedStatement) conn.prepareStatement(SQL4);
		ps8.setInt(1, idCarrello);
		ps8.setInt(2,idProdotto);
		ps8.executeUpdate();
		
		
		//inserisco un ordine relativo all'utente fittizio
		String SQL1 ="insert into ordine (utenteOrdine,prezzoTotale,stato) values "+ "('userTest',999.99,'Da Spedire')";
		PreparedStatement ps1 = (PreparedStatement) conn.prepareStatement(SQL1);		
		ps1.executeUpdate();
		
		//prendo l'id dell'ordine appena creato
		String SQL2 ="select id from ordine where utenteOrdine = 'userTest' && stato = 'Da Spedire'  && iban is NULL;";
		PreparedStatement ps2 = (PreparedStatement) conn.prepareStatement(SQL2);		
		ResultSet rsi = ps2.executeQuery();
		
		while(rsi.next())
			idOrdine= rsi.getInt(1);
		
		//inserisco i prodotti nell'ordine usando l'id prima trovato
		String SQL3 ="insert into prodottiOrdine (idOrdine,idProdottoLista,numeroProdotto) values (?,?,?)";
		PreparedStatement preparedStatement3 = (PreparedStatement) conn.prepareStatement(SQL3);
		preparedStatement3.setInt(1, idOrdine);
		preparedStatement3.setInt(2, idProdotto);
		preparedStatement3.setInt(3, idProdotto);
		preparedStatement3.executeUpdate();
	}

	@AfterEach
	void tearDown() throws Exception {
		
		conn = ordineModel.getConnection();
		
		
		//cancello i riferimenti ai test nel db
		String SQL4 ="delete from prodotticarrello where numeroCarrello=?";
		PreparedStatement ps8 = (PreparedStatement) conn.prepareStatement(SQL4);
		ps8.setInt(1, idCarrello);
		ps8.executeUpdate();
		
		
		String carrelloSQL ="delete from carrello where utentecarrello='userTest'";
		PreparedStatement ps5 = (PreparedStatement) conn.prepareStatement(carrelloSQL);		
		ps5.executeUpdate();
		
		
		String prodottiSQL ="delete from prodottiOrdine where idOrdine=?";
		PreparedStatement ps6 = (PreparedStatement) conn.prepareStatement(prodottiSQL);	
		ps6.setInt(1, idOrdine);
		ps6.executeUpdate();
		
		String ordineSQL ="delete from ordine where utenteOrdine='userTest'";
		PreparedStatement ps9 = (PreparedStatement) conn.prepareStatement(ordineSQL);		
		ps9.executeUpdate();
		
		String utenteSQL ="delete from utente where username='userTest'";
		PreparedStatement ps7 = (PreparedStatement) conn.prepareStatement(utenteSQL);		
		ps7.executeUpdate();
		
		
		
		String elimProdottoSQL ="delete from prodotto where idProdotto="+idProdotto+"";
		PreparedStatement ps10 = (PreparedStatement) conn.prepareStatement(elimProdottoSQL);		
		ps10.executeUpdate();
		
	}

	@Test
	final void testGetConnection() throws SQLException {
		assertNotNull(ordineModel.getConnection());
	}

	@Test
	final void testReturnOrdini() throws SQLException {
		assertNotNull(ordineModel.returnOrdini());
	}

	@Test
	final void testReturnOrdiniUtente() throws SQLException {
		assertNotNull(ordineModel.returnOrdiniUtente("userTest"));
	}

	@Test
	final void testAvanzaStato() throws SQLException {
		ordineModel.avanzaStato("Spedito",idOrdine);
		String SQL = "select stato from ordine where id="+idOrdine+"";
		PreparedStatement query = (PreparedStatement) conn.prepareStatement(SQL);
		ResultSet rs = query.executeQuery(SQL);
		String stato="";
		while(rs.next()) {
			stato=rs.getString(1);
		}
		
		assertEquals("Spedito",stato);
	}

	
	@Test
	final void testCreaOrdine() throws SQLException {
		//Cancello i riferimenti all'ordine di test creato nel setup
		
		String ordineSQL ="delete from ordine where utenteOrdine='userTest'";
		PreparedStatement ps9 = (PreparedStatement) conn.prepareStatement(ordineSQL);		
		ps9.executeUpdate();
		
		int id1 = ordineModel.creaOrdine(1,"userTest", 99.70);
		
		
		//controllo se � stato creato l'ordine correttamente
		String SQL = "select id from ordine where utenteOrdine='userTest' order by id desc; ";
		PreparedStatement query = (PreparedStatement) conn.prepareStatement(SQL);
		ResultSet rs = query.executeQuery(SQL);
		int id=0;
		if(rs.first()) {
			
			id=rs.getInt(1);
		}
		
		idTest=id;
		
		assertEquals(id, id1);
			
	}

	@Test
	final void testInserisciIban() throws SQLException {
		
		ordineModel.inserisciIban(idOrdine, "testIban");
		
		
		//controllo se l'iban � stato associato all'ordine
		String SQL1 = "select iban from ordine where id="+idOrdine+"";
		PreparedStatement query1 = (PreparedStatement) conn.prepareStatement(SQL1);
		ResultSet rs1 = query1.executeQuery(SQL1);
		String iban="";
		if(rs1.first()) {
			
			iban=rs1.getString(1);
		}
	
	assertEquals("testIban",iban);

}
	
	@Test
	final void testEliminaOrdine() throws SQLException {
		
		//provo ad eliminare un ordine con un id che non esiste
		assertEquals(false, ordineModel.eliminaOrdine(999));
		
		
		
		//elimino l'ordine corretto di test
		ordineModel.eliminaOrdine(idOrdine);
		
		
		
		
		
		//controllo se � stato eliminato l'ordine dal db
		String SQL = "select count(*) as conteggio from ordine where utenteOrdine='userTest'";
		PreparedStatement query = (PreparedStatement) conn.prepareStatement(SQL);
		ResultSet rs = query.executeQuery(SQL);
		int conteggio=0;
		if(rs.first()) {
			
			conteggio=rs.getInt("conteggio");
		}
		
		assertEquals(0, conteggio);
		
		
	}

}
