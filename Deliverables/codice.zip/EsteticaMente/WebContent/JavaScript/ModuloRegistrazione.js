/**
 * controlla modulo registrazione
 */

  	function ModuloRegistrazione() {
  		/*variabili*/
  	var nome = document.modulo.nome.value;
	var cognome = document.modulo.cognome.value;
	var eMail = document.modulo.eMail.value;
	var codiceFiscale = document.modulo.codiceFiscale.value;
	var dataNascita = document.modulo.dataNascita.value;
	var cittaNascita = document.modulo.cittaNascita.value;
	var cittaResidenza = document.modulo.cittaResidenza.value;
	var via = document.modulo.via.value;
	var numeroCivico = document.modulo.numeroCivico.value;
	var cap = document.modulo.cap.value;
	var username = document.modulo.username.value;
	var password1 = document.modulo.password1.value;
	var password2 = document.modulo.password2.value;
	var cf_control = /[a-z]{6}\d{2}[abcdehlmprst]\d{2}[a-z]\d{3}[a-z]/i;
	var dataC = new Date();
	
	/*controllo*/
	if((nome == "") || (nome == "undefined")) {
		alert("Campo obbligatorio! Inserire il nome!");
		document.reg.nome.focus();
		return false;
	} else if((cognome == "") || (cognome == "undefined")) {
		alert("Campo obbligatorio! Inserire il cognome!");
		document.reg.cognome.focus();
		return false;
	}else if((eMail == "") || (eMail == "undefined")) {
		alert("Campo obbligatorio! Inserire il e-Mail!");
		document.reg.cognome.focus();
		return false;
	}else if((codiceFiscale == "") || (codiceFiscale == "undefined") || (!cf_control.test(cf))) {
		alert("Attenzione! Controllare il codice fiscale inserito!");
		document.reg.codiceFiscale.value = "";
		document.reg.codiceFiscale.focus();
		return false;
	}else if((document.reg.dataNascita.value.substring(2, 3) != '/') ||
			  (document.reg.dataNascita.value.substring(5, 6) != '/') ||
			   isNaN(document.reg.dataNascita.value.substring(0, 2))  ||
			   isNaN(document.reg.dataNascita.value.substring(3, 5))  ||
			   isNaN(document.reg.dataNascita.value.substring(6, 10))) {
		alert("Campo obbligatorio! Inserire la data nel formato gg/mm/aaaa");
		document.reg.dataNascita.value = "";
		document.reg.dataNascita.focus();
		return false;
	} else if(document.reg.dataNascita.value.substring(0, 2) > 31) {
		alert("Inserire un valore idoneo per il giorno della data!");
		document.reg.dataNascita.focus();
		return false;
	} else if(document.reg.dataNascita.value.substring(3, 5) > 12) {
		alert("Inserire un valore idoneo per il mese della data!");
		document.reg.dataNascita.focus();
		return false;
	} else if((document.reg.dataNascita.value.substring(6, 10) < 1900) || 
			  (document.reg.dataNascita.value.substring(6, 10) > (dataC.getFullYear()-18))) {
		alert("Attenzione! L'anno di nascita deve essere compreso tra 1900 e" + (dataC.getFullYear()-18) + "!");
		document.reg.dataNascita.focus();
		return false;
	}else if((cittaNascita == "") || (cittaNascita == "undefined")) {
		alert("Campo obbligatorio! Inserire il citta Nascita!");
		document.reg.cittaNascita.focus();
		return false;
	}else if((cittaResidenza == "") || (cittaResidenza == "undefined")) {
		alert("Campo obbligatorio! Inserire il citta Residenza!");
		document.reg.cittaResidenza.focus();
		return false;
	}else if((via == "") || (via == "undefined")) {
		alert("Campo obbligatorio! Inserire il via!");
		document.reg.via.focus();
		return false;
	}else if((numeroCivico == "") || (numeroCivico == "undefined")) {
		alert("Campo obbligatorio! Inserire il numero Civico!");
		document.reg.numeroCivico.focus();
		return false;
	}else if((cap == "") || (cap == "undefined")) {
		alert("Campo obbligatorio! Inserire il cap!");
		document.reg.cap.focus();
		return false;
	} else if((username == "") || (username == "undefined")) {
		alert("Attenzione! Controllare l'username!");
		document.reg.username.value = "";
		document.reg.username.focus();
		return false;
	} else if((password1 == "") || (password1 == "undefined")) {
		alert("Attenzione! Controllare la password!");
		document.reg.password1.value = "";
		document.reg.password1.focus();
		return false;
	} else if((password2 == "") || (password2 == "undefined")) {
		alert("Attenzione! Controllare il reinserimento della password!");
		document.reg.password2.value = "";
		document.reg.password2.focus();
		return false;
	} else if(password1 != password2) {
		alert("Attenzione! Le password non sono uguali!");
		document.reg.password1.value = "";
		document.reg.password2.focus();
		return false;
	} else {
		return true;
	}
	
	
	/*fine funzione*/
  	}
	